<?php 

require 'vendor/autoload.php';

// instantiate the App object
$app = new \Slim\App();


function getDB(){
	$dbhost = "localhost";
	$dbname = "db_teknol";
	$dbuser = "root";
	$dbpass = "root";


try {
    $conn = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connected successfully"; 
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
 
	return $conn;

}



// Add route callbacks
$app->get('/', function ($request, $response, $args) {

    //return $response->withStatus(200)->write('probando raíz ');

try {

	$db= getDB(); 
	$sth = $db->prepare("SELECT msj_id, msj_nombre, msj_correo, msj_comentario FROM tbl_mensajes");

	$sth->execute();
	$registros = $sth->fetchAll(PDO::FETCH_ASSOC);

	if ($registros) {
		$response=$response->withJson($registros);
		$db=null;
	}

} catch (PDOException $e) {
	$response->write('{"estado":'.$e->getMessage().'}');
}
   return $response; 
});

	//http://localhost/teknol_api/add
	//insert /post para puebas locales en web
$app->post('/add', function($request, $response){
   
	try {

		$data = $request->getParams();
		$db   = getDB(); 
		$sth  = $db->prepare("INSERT INTO tbl_mensajes
			(msj_nombre, msj_correo, msj_comentario)
			VALUES(?,?,?)
			");
		$sth->execute(array( $data["msj_nombre"], $data["msj_correo"], $data["msj_comentario"] ));
		
		$response->write('{"estado":"1"}');

	} catch (PDOException $e) {
		//$response->write('error de algo');
		$response->write('{"estado":'.$e->getMessage().'}');
	}

return $response;

}); //post add nuevo registro







// Run application
$app->run();

 ?>




